# libbladeRF for Android (and, for testing, Linux): one shared library,
# libbladeRF.so, with libusb linked in statically.
#
# Sources are Nuand's libbladeRF 2.6.1 (git 35174c3) and libusb 1.0.29,
# vendored unchanged except for ONE file:
#   bladeRF/host/libraries/libbladeRF/src/backend/usb/libusb.c
# which gains bladerf_set_usb_fd() so an unrooted phone can open the board
# through the descriptor Android's UsbManager hands out
# (see libbladeRF-android-fd.patch next to this file).
#
# The three generated headers in bladeRF/generated/ come from Nuand's own
# CMake run on Linux; the Linux values are right for Android too (bionic has
# <endian.h> and clock_gettime).
cmake_minimum_required(VERSION 3.18)
project(bladerf_android C)

set(CMAKE_C_STANDARD 11)
set(CMAKE_C_EXTENSIONS ON)          # gnu11, as Nuand builds it
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

set(B ${CMAKE_CURRENT_SOURCE_DIR}/bladeRF)
set(U ${CMAKE_CURRENT_SOURCE_DIR}/libusb)

# ------------------------------------------------------------------ libusb
add_library(usb1 STATIC
    ${U}/libusb/core.c
    ${U}/libusb/descriptor.c
    ${U}/libusb/hotplug.c
    ${U}/libusb/io.c
    ${U}/libusb/sync.c
    ${U}/libusb/strerror.c
    ${U}/libusb/os/linux_usbfs.c
    ${U}/libusb/os/events_posix.c
    ${U}/libusb/os/threads_posix.c
    ${U}/libusb/os/linux_netlink.c)
target_include_directories(usb1 PRIVATE ${U} ${U}/libusb ${U}/libusb/os)
target_include_directories(usb1 PUBLIC ${U}/libusb)
target_compile_options(usb1 PRIVATE -fvisibility=hidden -pthread -Wno-unused-parameter)
if(ANDROID)
    target_link_libraries(usb1 PUBLIC log)
else()
    # config.h is Android's; on a desktop Linux test build the system log
    # facility it asks for does not exist.
    target_compile_definitions(usb1 PRIVATE USE_SYSTEM_LOGGING_FACILITY=0)
    target_link_libraries(usb1 PUBLIC pthread)
endif()

# ------------------------------------------------------------- AD9361 driver
set(AD936X_SRC
    ${B}/ad936x/ad9361.c
    ${B}/ad936x/ad9361_api.c
    ${B}/ad936x/ad9361_conv.c
    ${B}/ad936x/util.c
    ${B}/thirdparty/analogdevicesinc/no-OS_local/platform_bladerf2/platform.c
    ${B}/thirdparty/analogdevicesinc/no-OS_local/platform_bladerf2/adc_core.c
    ${B}/thirdparty/analogdevicesinc/no-OS_local/platform_bladerf2/dac_core.c
    ${B}/fpga_common/src/ad936x_params.c)
add_library(ad936x STATIC ${AD936X_SRC})
target_include_directories(ad936x PRIVATE
    ${B}/thirdparty/analogdevicesinc/no-OS_local/platform_bladerf2
    ${B}/ad936x
    ${B}/host/libraries/libbladeRF/src
    ${B}/host/libraries/libbladeRF/include
    ${B}/host/common/include
    ${B}/firmware_common
    ${B}/generated
    ${B}/fpga_common/include)
target_compile_definitions(ad936x PRIVATE NUAND_MODIFICATIONS=1)
target_compile_options(ad936x PRIVATE -Os -ffunction-sections -fdata-sections
    -Wno-unused-but-set-variable -w)

# --------------------------------------------------------------- libbladeRF
set(LB ${B}/host/libraries/libbladeRF/src)
add_library(bladeRF SHARED
    ${LB}/backend/backend.c
    ${LB}/driver/spi_flash.c
    ${LB}/driver/fx3_fw.c
    ${LB}/driver/fpga_trigger.c
    ${LB}/driver/si5338.c
    ${LB}/driver/ina219.c
    ${LB}/driver/dac161s055.c
    ${LB}/driver/smb_clock.c
    ${LB}/board/bladerf1/bladerf1.c
    ${LB}/board/bladerf1/capabilities.c
    ${LB}/board/bladerf1/compatibility.c
    ${LB}/board/bladerf1/calibration.c
    ${LB}/board/bladerf1/flash.c
    ${LB}/board/bladerf1/image.c
    ${LB}/board/board.c
    ${LB}/expansion/xb100.c
    ${LB}/expansion/xb200.c
    ${LB}/expansion/xb300.c
    ${LB}/streaming/async.c
    ${LB}/streaming/sync.c
    ${LB}/streaming/sync_worker.c
    ${LB}/init_fini.c
    ${LB}/helpers/timeout.c
    ${LB}/helpers/file.c
    ${LB}/helpers/version.c
    ${LB}/helpers/wallclock.c
    ${LB}/helpers/interleave.c
    ${LB}/helpers/configfile.c
    ${B}/thirdparty/lzma/CpuArch.c
    ${B}/thirdparty/lzma/LzFind.c
    ${B}/thirdparty/lzma/LzFindOpt.c
    ${B}/thirdparty/lzma/LzmaEnc.c
    ${LB}/devinfo.c
    ${LB}/device_calibration.c
    ${LB}/bladerf.c
    ${B}/host/common/src/sha256.c
    ${B}/host/common/src/conversions.c
    ${B}/host/common/src/log.c
    ${B}/fpga_common/src/lms.c
    ${B}/fpga_common/src/band_select.c
    ${B}/host/common/src/parse.c
    ${B}/host/common/src/range.c
    ${B}/fpga_common/src/ad936x_helpers.c
    ${B}/fpga_common/src/bladerf2_common.c
    ${LB}/board/bladerf2/bladerf2.c
    ${LB}/board/bladerf2/capabilities.c
    ${LB}/board/bladerf2/common.c
    ${LB}/board/bladerf2/compatibility.c
    ${LB}/board/bladerf2/rfic_fpga.c
    ${LB}/board/bladerf2/rfic_host.c
    ${LB}/backend/usb/nios_access.c
    ${LB}/backend/usb/nios_legacy_access.c
    ${LB}/backend/usb/usb.c
    ${LB}/backend/usb/libusb.c)
target_include_directories(bladeRF PRIVATE
    ${B}/host/libraries/libbladeRF/include
    ${LB}
    ${B}/host/common/include
    ${B}/generated
    ${B}/firmware_common
    ${B}/fpga_common/include
    ${B}/thirdparty/lzma
    ${B}/thirdparty/analogdevicesinc/no-OS_local/platform_bladerf2
    ${B}/ad936x)
target_compile_definitions(bladeRF PRIVATE
    ENABLE_USB_DEV_RESET_ON_OPEN=1
    HAVE_LIBUSB_GET_VERSION
    LIBBLADERF_SEARCH_PREFIX="/data/local/tmp"
    LOGGING_ENABLED
    NUAND_MODIFICATIONS=1
    Z7_ST)            # lzma single-threaded, as Nuand builds it
target_compile_options(bladeRF PRIVATE -fvisibility=hidden -O2
    -Wall -Wno-unused-parameter -Wno-unused-but-set-variable)
target_link_libraries(bladeRF PRIVATE ad936x usb1 m)
if(ANDROID)
    target_link_libraries(bladeRF PRIVATE log)
    # 16 KB page alignment, required for apps targeting Android 15+ devices
    target_link_options(bladeRF PRIVATE "-Wl,-z,max-page-size=16384")
endif()
