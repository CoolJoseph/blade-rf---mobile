#ifndef VERSION_H_
#define VERSION_H_

#define LIBBLADERF_VERSION "2.6.1-git-35174c3"

// clang-format off
#define LIBBLADERF_VERSION_MAJOR 2
#define LIBBLADERF_VERSION_MINOR 6
#define LIBBLADERF_VERSION_PATCH 1
// clang-format on

#endif
